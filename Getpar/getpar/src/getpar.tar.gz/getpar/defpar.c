/*
 * Copyright 1992 Science Applications International Corporation.
 *
 * NAME
 *	getbpar()
 *      getdpar()
 *      getfpar()
 *      getffpar()
 * 
 * FILE 
 *	defpar.c
 *
 * SYNOPSIS
 *      par->duration = getffpar ("duration", 200.0);
 *	
 * DESCRIPTION
 *
 * DIAGNOSTICS
 *
 * FILES
 *
 * NOTES
 * 
 * SEE ALSO
 *
 * AUTHOR
 * 	Rick Jenkins  10/08/92
 *
 */

/* SCCS ID. */
#ifndef lint
static char SccsId[]="@(#)defpar.c	56.1 10/25/93 Copywright 1992 Science Applications International Corporation.";
#endif

int
getbpar(parname, defvalue)
char *parname;
int defvalue;
{
	int parvalue = defvalue;
	
	getpar (parname, "b", &parvalue);

	return (parvalue);
}

int
getdpar(parname, defvalue)
char *parname;
int defvalue;
{
	int parvalue = defvalue;
	
	getpar (parname, "d", &parvalue);

	return (parvalue);
}

float
getfpar(parname, defvalue)
char *parname;
float defvalue;
{
	float parvalue = defvalue;
	
	getpar (parname, "f", &parvalue);

	return (parvalue);
}

double
getffpar(parname, defvalue)
char *parname;
double defvalue;
{
	double parvalue = defvalue;
	
	getpar (parname, "F", &parvalue);

	return (parvalue);
}

/****************************************************************************/
