  /*
   *  libpar.h include file.
   *
   *  Provide function definitions/prototypes for the 
   *  routines found in libpar.a.  Note these routines may change if 
   *  a new release of libpar is received.  Unfortunately this file 
   *  and the release are independent.
   */
    
#ifndef LIBPAR_H
#define LIBPAR_H
    
#ifdef __STDC__

extern int	countarg (char *name, char *type);
extern void	endarg (void);
extern void	endpar (void);
extern int	getarg (char *name, char *type, int *ptr_to_some_type);
extern int	getpar (char *name, char *type, int *ptr_to_some_type);
extern int	lenarg (char *name);
extern int	mstpar (char *name, char *type, int *ptr_to_some_type);
extern void	setarg (char *list, char *subname);
extern int	setpar (int argc, char **argv);
extern char    *getspar(char *name, char *def);
extern char    *mstspar(char *name);
extern char    *getsarg(char *name, char *def);

#else	/* ! __STDC__ */

extern int	countarg ();
extern void	endarg ();
extern void	endpar ();
extern int	getarg ();
extern int	getpar ();
extern int	lenarg ();
extern int	mstpar ();
extern void	setarg ();
extern int	setpar ();
extern char    *getspar();
extern char    *mstspar();
extern char    *getsarg();

#endif	/* __STDC__ */

#endif	/* LIBPAR_H */
